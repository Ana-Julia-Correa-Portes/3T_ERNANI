// LOOOP WHILE (EQUANTO)
// RODA NUM LOOP INFINITO POR PADRÃO
// MAS PODEMOS ESTIPULAR UMA CONDIÇÃO
// DE PARADA PARA CNTROLÁ-LO
// SINTAXE : WHILE (CONDIÇÃO) {CÓDIGO}
let n = 0
while (n < 100) {
   // console.clear();
if (n % 2 == 1){
  // SE O RESTO FOR 0 (É PAR)
  // SE O RESTO FOR 1 (É ÍMPAR)
  console.log(n);
}
n = n+1;
  }