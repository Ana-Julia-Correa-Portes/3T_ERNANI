const fs = require("node:fs");

module.exports = { fs };
