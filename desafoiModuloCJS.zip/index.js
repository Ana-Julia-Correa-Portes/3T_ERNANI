import { acelerar } from "./LIB/veiculo.js";
console.log(acelerar());
console.log(acelerar());
console.log(acelerar());
