// arrays são indexados
// possuem métodos
// podem ser iterados
const nome = "Marta";
const time = ["Rodrigo", "Noah", "Henrique", "Carlos"];
// (PARENTESES), [COLCHETES], {CHAVES}
time.push("Leandra"); // ADICIONA NO FINAL DA LISTA
time.shift(); // REMOV O PRIMEIRO DA LISTA
console.log(time);
console.log(time[3]); // Carlos
console.log(time[13]); // undefined
time[13] = "Maria";
console.log(time[13]); // Maria
console.log(time.length); // TAMANHO DA ARRAY
// ITERRAR - LOOP ATÉ O ESGOTAMENTO (FOR, FOREACH, WHILE, FOR IN, FOR OF)
for (var i = 0; i <= 4; i++) {
  console.log(time[i]);
}
