
// FUNÇÃO

const internal = require("stream")

// DECLARAÇÃO
function dizOlá(){
  console.log('Olá')
}
function olaPessoa(nome){
  console.log(`Olá, ${nome}`)
}
const nome= 'Maria'
const idade= 18

function retornaDados (){
  return `nome: ${nome}, idade: ${idade}`
}



// INVOCAÇÃO 
dizOlá();
olaPessoa('Maria');
console.log(retornaDados());

// FUNÇÕES PERSONALIZADAS VS FUNÇÕES NATIVAS

let salario = 1000

const intervalo01 = setInterval(function(){
  console.clear()
  salario = salario + 100;
  console.log(`Ganhei ${salario}`)
}, 2000) //tempo ms
/*
setInterval - clearInterval
setInterval - clearTimeout
*/
setTimeout(function () {
  console.log("---------------");
  clearInterval(intervalo01);
  console.info("Intervalo encerrado")
}, 5000);

