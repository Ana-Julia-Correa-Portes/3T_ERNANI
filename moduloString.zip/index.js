// IMPORTANDO MÓDULOS
import  {nome, olaPessoa, textoMaiusculas} from'./lib/Strings.js';
// IMPORTAÇÃO DEFAULT
export textoMaiusculas from'./lib/Strings.js';

console.log(nome)


olaPessoa()
textoMaiusculas('arrz e feijãõ')
console.log (textoMaiusculas("Carlos""))